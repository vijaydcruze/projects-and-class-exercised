
using ReportingSystem.Core;

namespace ReportingSystem.Formatters
{
    public class ExcelReportFormatter : IReportFormatter
    {
        public string Format(string content)
        {
            return $"Excel Format: {content}";
        }
    }
}
