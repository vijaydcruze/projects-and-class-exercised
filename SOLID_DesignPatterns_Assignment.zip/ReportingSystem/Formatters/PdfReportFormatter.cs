
using ReportingSystem.Core;

namespace ReportingSystem.Formatters
{
    public class PdfReportFormatter : IReportFormatter
    {
        public string Format(string content)
        {
            return $"PDF Format: {content}";
        }
    }
}
