
using System;
using ReportingSystem.Core;

namespace ReportingSystem.Savers
{
    public class FileReportSaver : IReportSaver
    {
        public void Save(string formattedContent)
        {
            Console.WriteLine("Saving Report: " + formattedContent);
        }
    }
}
