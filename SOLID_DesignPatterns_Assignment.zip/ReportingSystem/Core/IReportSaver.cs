
namespace ReportingSystem.Core
{
    public interface IReportSaver
    {
        void Save(string formattedContent);
    }
}
