
namespace ReportingSystem.Core
{
    public interface IReportFormatter
    {
        string Format(string content);
    }
}
