
namespace ReportingSystem.Core
{
    public interface IReportGenerator
    {
        string GenerateReport();
    }
}
