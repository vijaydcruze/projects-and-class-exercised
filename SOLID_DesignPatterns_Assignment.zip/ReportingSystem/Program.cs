
using System;
using ReportingSystem.Core;
using ReportingSystem.Services;
using ReportingSystem.Formatters;
using ReportingSystem.Savers;
using ReportingSystem.Patterns.Singleton;
using ReportingSystem.Patterns.Factory;
using ReportingSystem.Patterns.Observer;

namespace ReportingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            // ===== SOLID DEMO =====
            IReportGenerator generator = new SalesReportGenerator();
            IReportFormatter formatter = new PdfReportFormatter();
            IReportSaver saver = new FileReportSaver();

            ReportService service = new ReportService(generator, formatter, saver);
            service.ProcessReport();

            // ===== Singleton Pattern =====
            Logger logger1 = Logger.Instance;
            Logger logger2 = Logger.Instance;
            logger1.Log("Singleton Logger Working!");

            // ===== Factory Pattern =====
            IDocument doc = DocumentFactory.CreateDocument("pdf");
            doc.Open();

            // ===== Observer Pattern =====
            WeatherStation station = new WeatherStation();
            WeatherDisplay display = new WeatherDisplay();

            station.Register(display);
            station.SetTemperature(30);
        }
    }
}
