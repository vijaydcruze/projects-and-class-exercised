
using System.Collections.Generic;

namespace ReportingSystem.Patterns.Observer
{
    public class WeatherStation : ISubject
    {
        private readonly List<IObserver> _observers = new();
        private int _temperature;

        public void Register(IObserver observer)
        {
            _observers.Add(observer);
        }

        public void Unregister(IObserver observer)
        {
            _observers.Remove(observer);
        }

        public void SetTemperature(int temperature)
        {
            _temperature = temperature;
            Notify();
        }

        public void Notify()
        {
            foreach (var observer in _observers)
            {
                observer.Update(_temperature);
            }
        }
    }
}
