
using System;

namespace ReportingSystem.Patterns.Observer
{
    public class WeatherDisplay : IObserver
    {
        public void Update(int temperature)
        {
            Console.WriteLine("Temperature Updated: " + temperature);
        }
    }
}
