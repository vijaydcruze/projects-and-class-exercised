
namespace ReportingSystem.Patterns.Observer
{
    public interface IObserver
    {
        void Update(int temperature);
    }
}
