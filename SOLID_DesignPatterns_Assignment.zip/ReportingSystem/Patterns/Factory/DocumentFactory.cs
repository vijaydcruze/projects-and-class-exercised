
namespace ReportingSystem.Patterns.Factory
{
    public class DocumentFactory
    {
        public static IDocument CreateDocument(string type)
        {
            return type.ToLower() switch
            {
                "pdf" => new PdfDocument(),
                "word" => new WordDocument(),
                _ => throw new System.ArgumentException("Invalid document type")
            };
        }
    }
}
