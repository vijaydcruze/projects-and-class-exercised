
namespace ReportingSystem.Patterns.Factory
{
    public interface IDocument
    {
        void Open();
    }
}
