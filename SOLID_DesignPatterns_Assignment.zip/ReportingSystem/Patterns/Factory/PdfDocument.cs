
using System;

namespace ReportingSystem.Patterns.Factory
{
    public class PdfDocument : IDocument
    {
        public void Open()
        {
            Console.WriteLine("Opening PDF Document");
        }
    }
}
