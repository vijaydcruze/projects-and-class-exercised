
using ReportingSystem.Core;

namespace ReportingSystem.Services
{
    public class SalesReportGenerator : IReportGenerator
    {
        public string GenerateReport()
        {
            return "Sales Report Data";
        }
    }
}
