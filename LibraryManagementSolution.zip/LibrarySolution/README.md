# Library Management System – Wipro NGA .NET Cohort

## Project Structure

```
LibrarySolution/
├── LibrarySolution.sln
├── LibraryManagement/                        # Class library
│   ├── LibraryManagement.csproj
│   ├── Book.cs                               # Book entity
│   ├── Borrower.cs                           # Borrower entity
│   └── Library.cs                            # Core library service
└── LibraryManagement.Tests/                  # NUnit test project
    ├── LibraryManagement.Tests.csproj
    ├── BookTests.cs                           # Tests for Book class
    ├── BorrowerTests.cs                       # Tests for Borrower class
    └── LibraryTests.cs                        # Tests for Library class (all user stories)
```

## Prerequisites

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)

## How to Build & Run Tests

```bash
# Restore NuGet packages
dotnet restore

# Build solution
dotnet build

# Run all tests
dotnet test

# Run with detailed output
dotnet test --logger "console;verbosity=detailed"
```

## Class Design

### `Book`
| Member | Type | Description |
|---|---|---|
| `Title` | `string` | Title of the book (read-only) |
| `Author` | `string` | Author name (read-only) |
| `ISBN` | `string` | Unique ISBN number (read-only) |
| `IsBorrowed` | `bool` | Borrow status |
| `Borrow()` | method | Marks book as borrowed; throws if already borrowed |
| `Return()` | method | Marks book as available; throws if not borrowed |

### `Borrower`
| Member | Type | Description |
|---|---|---|
| `Name` | `string` | Borrower's name (read-only) |
| `LibraryCardNumber` | `string` | Unique card number (read-only) |
| `BorrowedBooks` | `IReadOnlyList<Book>` | Currently borrowed books |
| `BorrowBook(Book)` | method | Borrows a book and marks it borrowed |
| `ReturnBook(Book)` | method | Returns a book and marks it available |

### `Library`
| Member | Type | Description |
|---|---|---|
| `Books` | `IReadOnlyList<Book>` | All books in the library |
| `Borrowers` | `IReadOnlyList<Borrower>` | All registered borrowers |
| `AddBook(Book)` | method | Adds a book (enforces unique ISBN) |
| `RegisterBorrower(Borrower)` | method | Registers borrower (enforces unique card) |
| `BorrowBook(isbn, cardNumber)` | method | Borrow a book by ISBN and card number |
| `ReturnBook(isbn, cardNumber)` | method | Return a book by ISBN and card number |
| `ViewBooks()` | method | Returns formatted string of all books + status |
| `ViewBorrowers()` | method | Returns formatted string of all borrowers + books |

## Test Coverage Summary

| Test File | Scenarios Covered |
|---|---|
| `BookTests.cs` | Construction, Borrow, Return, edge cases, ToString |
| `BorrowerTests.cs` | Construction, BorrowBook, ReturnBook, multiple books, nulls |
| `LibraryTests.cs` | All 5 user stories: add book, register borrower, borrow, return, view |
