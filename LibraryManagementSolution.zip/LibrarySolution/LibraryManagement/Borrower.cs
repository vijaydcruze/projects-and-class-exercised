namespace LibraryManagement;

/// <summary>
/// Represents a library borrower (member).
/// </summary>
public class Borrower
{
    /// <summary>Gets the name of the borrower.</summary>
    public string Name { get; }

    /// <summary>Gets the library card number of the borrower.</summary>
    public string LibraryCardNumber { get; }

    /// <summary>Gets the list of books currently borrowed by this borrower.</summary>
    public IReadOnlyList<Book> BorrowedBooks => _borrowedBooks.AsReadOnly();

    private readonly List<Book> _borrowedBooks = new();

    /// <summary>
    /// Initializes a new instance of the <see cref="Borrower"/> class.
    /// </summary>
    /// <param name="name">The name of the borrower.</param>
    /// <param name="libraryCardNumber">The unique library card number.</param>
    /// <exception cref="ArgumentException">Thrown when name or libraryCardNumber is null or empty.</exception>
    public Borrower(string name, string libraryCardNumber)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Name cannot be null or empty.", nameof(name));
        if (string.IsNullOrWhiteSpace(libraryCardNumber))
            throw new ArgumentException("Library card number cannot be null or empty.", nameof(libraryCardNumber));

        Name = name;
        LibraryCardNumber = libraryCardNumber;
    }

    /// <summary>
    /// Borrows a book, associating it with this borrower.
    /// </summary>
    /// <param name="book">The book to borrow.</param>
    /// <exception cref="ArgumentNullException">Thrown when book is null.</exception>
    /// <exception cref="InvalidOperationException">Thrown when the borrower has already borrowed this book.</exception>
    public void BorrowBook(Book book)
    {
        if (book == null) throw new ArgumentNullException(nameof(book));

        if (_borrowedBooks.Contains(book))
            throw new InvalidOperationException($"Borrower '{Name}' has already borrowed '{book.Title}'.");

        book.Borrow();
        _borrowedBooks.Add(book);
    }

    /// <summary>
    /// Returns a book, removing it from this borrower's list.
    /// </summary>
    /// <param name="book">The book to return.</param>
    /// <exception cref="ArgumentNullException">Thrown when book is null.</exception>
    /// <exception cref="InvalidOperationException">Thrown when this borrower has not borrowed the book.</exception>
    public void ReturnBook(Book book)
    {
        if (book == null) throw new ArgumentNullException(nameof(book));

        if (!_borrowedBooks.Contains(book))
            throw new InvalidOperationException($"Borrower '{Name}' has not borrowed '{book.Title}'.");

        book.Return();
        _borrowedBooks.Remove(book);
    }

    /// <inheritdoc />
    public override string ToString()
    {
        if (_borrowedBooks.Count == 0)
            return $"{Name} (Card: {LibraryCardNumber}) — No books borrowed.";

        var bookList = string.Join(", ", _borrowedBooks.Select(b => $"\"{b.Title}\""));
        return $"{Name} (Card: {LibraryCardNumber}) — Borrowed: {bookList}";
    }
}
