namespace LibraryManagement;

/// <summary>
/// Represents a book in the library system.
/// </summary>
public class Book
{
    /// <summary>Gets the title of the book.</summary>
    public string Title { get; }

    /// <summary>Gets the author of the book.</summary>
    public string Author { get; }

    /// <summary>Gets the ISBN number of the book.</summary>
    public string ISBN { get; }

    /// <summary>Gets a value indicating whether the book is currently borrowed.</summary>
    public bool IsBorrowed { get; private set; }

    /// <summary>
    /// Initializes a new instance of the <see cref="Book"/> class.
    /// </summary>
    /// <param name="title">The title of the book.</param>
    /// <param name="author">The author of the book.</param>
    /// <param name="isbn">The ISBN number of the book.</param>
    /// <exception cref="ArgumentException">Thrown when title, author, or ISBN is null or empty.</exception>
    public Book(string title, string author, string isbn)
    {
        if (string.IsNullOrWhiteSpace(title))
            throw new ArgumentException("Title cannot be null or empty.", nameof(title));
        if (string.IsNullOrWhiteSpace(author))
            throw new ArgumentException("Author cannot be null or empty.", nameof(author));
        if (string.IsNullOrWhiteSpace(isbn))
            throw new ArgumentException("ISBN cannot be null or empty.", nameof(isbn));

        Title = title;
        Author = author;
        ISBN = isbn;
        IsBorrowed = false;
    }

    /// <summary>
    /// Marks this book as borrowed.
    /// </summary>
    /// <exception cref="InvalidOperationException">Thrown when the book is already borrowed.</exception>
    public void Borrow()
    {
        if (IsBorrowed)
            throw new InvalidOperationException($"Book '{Title}' (ISBN: {ISBN}) is already borrowed.");

        IsBorrowed = true;
    }

    /// <summary>
    /// Marks this book as returned (available).
    /// </summary>
    /// <exception cref="InvalidOperationException">Thrown when the book is not currently borrowed.</exception>
    public void Return()
    {
        if (!IsBorrowed)
            throw new InvalidOperationException($"Book '{Title}' (ISBN: {ISBN}) is not currently borrowed.");

        IsBorrowed = false;
    }

    /// <inheritdoc />
    public override string ToString()
    {
        string status = IsBorrowed ? "Borrowed" : "Available";
        return $"[{status}] \"{Title}\" by {Author} (ISBN: {ISBN})";
    }
}
