namespace LibraryManagement;

/// <summary>
/// Represents the library system, managing books and borrowers.
/// </summary>
public class Library
{
    /// <summary>Gets a read-only list of all books in the library.</summary>
    public IReadOnlyList<Book> Books => _books.AsReadOnly();

    /// <summary>Gets a read-only list of all registered borrowers.</summary>
    public IReadOnlyList<Borrower> Borrowers => _borrowers.AsReadOnly();

    private readonly List<Book> _books = new();
    private readonly List<Borrower> _borrowers = new();

    // ─────────────────────────────────────────────
    // Book Management
    // ─────────────────────────────────────────────

    /// <summary>
    /// Adds a new book to the library.
    /// </summary>
    /// <param name="book">The book to add.</param>
    /// <exception cref="ArgumentNullException">Thrown when book is null.</exception>
    /// <exception cref="InvalidOperationException">Thrown when a book with the same ISBN already exists.</exception>
    public void AddBook(Book book)
    {
        if (book == null) throw new ArgumentNullException(nameof(book));

        if (_books.Any(b => b.ISBN == book.ISBN))
            throw new InvalidOperationException($"A book with ISBN '{book.ISBN}' already exists in the library.");

        _books.Add(book);
    }

    // ─────────────────────────────────────────────
    // Borrower Management
    // ─────────────────────────────────────────────

    /// <summary>
    /// Registers a new borrower with the library.
    /// </summary>
    /// <param name="borrower">The borrower to register.</param>
    /// <exception cref="ArgumentNullException">Thrown when borrower is null.</exception>
    /// <exception cref="InvalidOperationException">Thrown when a borrower with the same card number is already registered.</exception>
    public void RegisterBorrower(Borrower borrower)
    {
        if (borrower == null) throw new ArgumentNullException(nameof(borrower));

        if (_borrowers.Any(b => b.LibraryCardNumber == borrower.LibraryCardNumber))
            throw new InvalidOperationException($"A borrower with card number '{borrower.LibraryCardNumber}' is already registered.");

        _borrowers.Add(borrower);
    }

    // ─────────────────────────────────────────────
    // Borrow / Return Operations
    // ─────────────────────────────────────────────

    /// <summary>
    /// Allows a registered borrower to borrow a book by ISBN.
    /// </summary>
    /// <param name="isbn">The ISBN of the book to borrow.</param>
    /// <param name="libraryCardNumber">The library card number of the borrower.</param>
    /// <exception cref="InvalidOperationException">
    /// Thrown when the book or borrower is not found, or the book is already borrowed.
    /// </exception>
    public void BorrowBook(string isbn, string libraryCardNumber)
    {
        var book = FindBookByISBN(isbn);
        var borrower = FindBorrowerByCardNumber(libraryCardNumber);

        // Delegate the borrow logic to the Borrower (which also calls book.Borrow())
        borrower.BorrowBook(book);
    }

    /// <summary>
    /// Allows a registered borrower to return a previously borrowed book.
    /// </summary>
    /// <param name="isbn">The ISBN of the book to return.</param>
    /// <param name="libraryCardNumber">The library card number of the borrower.</param>
    /// <exception cref="InvalidOperationException">
    /// Thrown when the book or borrower is not found, or the borrower does not have this book.
    /// </exception>
    public void ReturnBook(string isbn, string libraryCardNumber)
    {
        var book = FindBookByISBN(isbn);
        var borrower = FindBorrowerByCardNumber(libraryCardNumber);

        // Delegate the return logic to the Borrower (which also calls book.Return())
        borrower.ReturnBook(book);
    }

    // ─────────────────────────────────────────────
    // View Operations
    // ─────────────────────────────────────────────

    /// <summary>
    /// Returns a formatted string listing all books and their status.
    /// </summary>
    public string ViewBooks()
    {
        if (_books.Count == 0)
            return "No books in the library.";

        return "=== Library Books ===\n" +
               string.Join("\n", _books.Select((b, i) => $"{i + 1}. {b}"));
    }

    /// <summary>
    /// Returns a formatted string listing all registered borrowers and their borrowed books.
    /// </summary>
    public string ViewBorrowers()
    {
        if (_borrowers.Count == 0)
            return "No borrowers registered.";

        return "=== Registered Borrowers ===\n" +
               string.Join("\n", _borrowers.Select((b, i) => $"{i + 1}. {b}"));
    }

    // ─────────────────────────────────────────────
    // Private Helpers
    // ─────────────────────────────────────────────

    private Book FindBookByISBN(string isbn)
    {
        var book = _books.FirstOrDefault(b => b.ISBN == isbn);
        if (book == null)
            throw new InvalidOperationException($"No book with ISBN '{isbn}' found in the library.");
        return book;
    }

    private Borrower FindBorrowerByCardNumber(string cardNumber)
    {
        var borrower = _borrowers.FirstOrDefault(b => b.LibraryCardNumber == cardNumber);
        if (borrower == null)
            throw new InvalidOperationException($"No borrower with card number '{cardNumber}' found.");
        return borrower;
    }
}
