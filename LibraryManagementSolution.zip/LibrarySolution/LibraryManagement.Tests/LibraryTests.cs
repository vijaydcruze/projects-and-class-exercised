using NUnit.Framework;
using LibraryManagement;

namespace LibraryManagement.Tests;

/// <summary>
/// Unit tests for the <see cref="Library"/> class, covering all user stories.
/// </summary>
[TestFixture]
public class LibraryTests
{
    private Library _library = null!;
    private Book _book1 = null!;
    private Book _book2 = null!;
    private Borrower _borrower1 = null!;
    private Borrower _borrower2 = null!;

    [SetUp]
    public void Setup()
    {
        _library = new Library();
        _book1 = new Book("Clean Code", "Robert C. Martin", "ISBN-001");
        _book2 = new Book("The Pragmatic Programmer", "Andy Hunt", "ISBN-002");
        _borrower1 = new Borrower("Alice Johnson", "LIB-1001");
        _borrower2 = new Borrower("Bob Smith", "LIB-1002");
    }

    // ─────────────────────────────────────────────
    // User Story 1: Add a New Book
    // ─────────────────────────────────────────────

    [Test]
    public void AddBook_ValidBook_BookIsStoredInLibrary()
    {
        _library.AddBook(_book1);

        Assert.That(_library.Books, Contains.Item(_book1));
    }

    [Test]
    public void AddBook_MultipleBooks_AllBooksAreStored()
    {
        _library.AddBook(_book1);
        _library.AddBook(_book2);

        Assert.That(_library.Books.Count, Is.EqualTo(2));
        Assert.That(_library.Books, Contains.Item(_book1));
        Assert.That(_library.Books, Contains.Item(_book2));
    }

    [Test]
    public void AddBook_DuplicateISBN_ThrowsInvalidOperationException()
    {
        var duplicateBook = new Book("Duplicate Title", "Some Author", "ISBN-001");
        _library.AddBook(_book1);

        Assert.Throws<InvalidOperationException>(() => _library.AddBook(duplicateBook));
    }

    [Test]
    public void AddBook_NullBook_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() => _library.AddBook(null!));
    }

    [Test]
    public void AddBook_NewLibrary_BooksListStartsEmpty()
    {
        Assert.That(_library.Books, Is.Empty);
    }

    // ─────────────────────────────────────────────
    // User Story 2: Register a Borrower
    // ─────────────────────────────────────────────

    [Test]
    public void RegisterBorrower_ValidBorrower_BorrowerIsStored()
    {
        _library.RegisterBorrower(_borrower1);

        Assert.That(_library.Borrowers, Contains.Item(_borrower1));
    }

    [Test]
    public void RegisterBorrower_MultipleBorrowers_AllBorrowersAreStored()
    {
        _library.RegisterBorrower(_borrower1);
        _library.RegisterBorrower(_borrower2);

        Assert.That(_library.Borrowers.Count, Is.EqualTo(2));
    }

    [Test]
    public void RegisterBorrower_DuplicateCardNumber_ThrowsInvalidOperationException()
    {
        var duplicateBorrower = new Borrower("Duplicate Name", "LIB-1001");
        _library.RegisterBorrower(_borrower1);

        Assert.Throws<InvalidOperationException>(() => _library.RegisterBorrower(duplicateBorrower));
    }

    [Test]
    public void RegisterBorrower_NullBorrower_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() => _library.RegisterBorrower(null!));
    }

    [Test]
    public void RegisterBorrower_NewLibrary_BorrowersListStartsEmpty()
    {
        Assert.That(_library.Borrowers, Is.Empty);
    }

    // ─────────────────────────────────────────────
    // User Story 3: Borrow a Book
    // ─────────────────────────────────────────────

    [Test]
    public void BorrowBook_ValidIsbnAndCard_BookIsMarkedAsBorrowed()
    {
        _library.AddBook(_book1);
        _library.RegisterBorrower(_borrower1);

        _library.BorrowBook("ISBN-001", "LIB-1001");

        Assert.That(_book1.IsBorrowed, Is.True);
    }

    [Test]
    public void BorrowBook_ValidIsbnAndCard_BookIsAssociatedWithBorrower()
    {
        _library.AddBook(_book1);
        _library.RegisterBorrower(_borrower1);

        _library.BorrowBook("ISBN-001", "LIB-1001");

        Assert.That(_borrower1.BorrowedBooks, Contains.Item(_book1));
    }

    [Test]
    public void BorrowBook_BookNotInLibrary_ThrowsInvalidOperationException()
    {
        _library.RegisterBorrower(_borrower1);

        Assert.Throws<InvalidOperationException>(() => _library.BorrowBook("INVALID-ISBN", "LIB-1001"));
    }

    [Test]
    public void BorrowBook_BorrowerNotRegistered_ThrowsInvalidOperationException()
    {
        _library.AddBook(_book1);

        Assert.Throws<InvalidOperationException>(() => _library.BorrowBook("ISBN-001", "INVALID-CARD"));
    }

    [Test]
    public void BorrowBook_AlreadyBorrowedBook_ThrowsInvalidOperationException()
    {
        _library.AddBook(_book1);
        _library.RegisterBorrower(_borrower1);
        _library.RegisterBorrower(_borrower2);
        _library.BorrowBook("ISBN-001", "LIB-1001");

        // Another borrower tries to borrow the same already-borrowed book
        Assert.Throws<InvalidOperationException>(() => _library.BorrowBook("ISBN-001", "LIB-1002"));
    }

    [Test]
    public void BorrowBook_MultipleBooksForSameBorrower_AllAssociatedCorrectly()
    {
        _library.AddBook(_book1);
        _library.AddBook(_book2);
        _library.RegisterBorrower(_borrower1);

        _library.BorrowBook("ISBN-001", "LIB-1001");
        _library.BorrowBook("ISBN-002", "LIB-1001");

        Assert.That(_borrower1.BorrowedBooks.Count, Is.EqualTo(2));
    }

    // ─────────────────────────────────────────────
    // User Story 4: Return a Book
    // ─────────────────────────────────────────────

    [Test]
    public void ReturnBook_BorrowedBook_BookIsMarkedAsAvailable()
    {
        _library.AddBook(_book1);
        _library.RegisterBorrower(_borrower1);
        _library.BorrowBook("ISBN-001", "LIB-1001");

        _library.ReturnBook("ISBN-001", "LIB-1001");

        Assert.That(_book1.IsBorrowed, Is.False);
    }

    [Test]
    public void ReturnBook_BorrowedBook_BookIsRemovedFromBorrowerList()
    {
        _library.AddBook(_book1);
        _library.RegisterBorrower(_borrower1);
        _library.BorrowBook("ISBN-001", "LIB-1001");

        _library.ReturnBook("ISBN-001", "LIB-1001");

        Assert.That(_borrower1.BorrowedBooks, Does.Not.Contain(_book1));
    }

    [Test]
    public void ReturnBook_AfterReturn_BookCanBeBorrowedAgain()
    {
        _library.AddBook(_book1);
        _library.RegisterBorrower(_borrower1);
        _library.RegisterBorrower(_borrower2);
        _library.BorrowBook("ISBN-001", "LIB-1001");
        _library.ReturnBook("ISBN-001", "LIB-1001");

        // A different borrower can now borrow the returned book
        Assert.DoesNotThrow(() => _library.BorrowBook("ISBN-001", "LIB-1002"));
    }

    [Test]
    public void ReturnBook_BookNotBorrowedByThisBorrower_ThrowsInvalidOperationException()
    {
        _library.AddBook(_book1);
        _library.RegisterBorrower(_borrower1);

        Assert.Throws<InvalidOperationException>(() => _library.ReturnBook("ISBN-001", "LIB-1001"));
    }

    [Test]
    public void ReturnBook_BookNotInLibrary_ThrowsInvalidOperationException()
    {
        _library.RegisterBorrower(_borrower1);

        Assert.Throws<InvalidOperationException>(() => _library.ReturnBook("INVALID-ISBN", "LIB-1001"));
    }

    // ─────────────────────────────────────────────
    // User Story 5: View Books and Borrowers
    // ─────────────────────────────────────────────

    [Test]
    public void ViewBooks_WithBooks_ContainsBookTitles()
    {
        _library.AddBook(_book1);
        _library.AddBook(_book2);

        string result = _library.ViewBooks();

        Assert.That(result, Does.Contain("Clean Code"));
        Assert.That(result, Does.Contain("The Pragmatic Programmer"));
    }

    [Test]
    public void ViewBooks_EmptyLibrary_ReturnsNoBookMessage()
    {
        string result = _library.ViewBooks();

        Assert.That(result, Does.Contain("No books"));
    }

    [Test]
    public void ViewBooks_ShowsAvailabilityStatus()
    {
        _library.AddBook(_book1);
        _library.RegisterBorrower(_borrower1);
        _library.BorrowBook("ISBN-001", "LIB-1001");

        string result = _library.ViewBooks();

        Assert.That(result, Does.Contain("Borrowed"));
    }

    [Test]
    public void ViewBorrowers_WithBorrowers_ContainsBorrowerNames()
    {
        _library.RegisterBorrower(_borrower1);
        _library.RegisterBorrower(_borrower2);

        string result = _library.ViewBorrowers();

        Assert.That(result, Does.Contain("Alice Johnson"));
        Assert.That(result, Does.Contain("Bob Smith"));
    }

    [Test]
    public void ViewBorrowers_EmptyLibrary_ReturnsNoBorrowerMessage()
    {
        string result = _library.ViewBorrowers();

        Assert.That(result, Does.Contain("No borrowers"));
    }

    [Test]
    public void ViewBorrowers_WithBorrowedBooks_ShowsBorrowedBookTitles()
    {
        _library.AddBook(_book1);
        _library.RegisterBorrower(_borrower1);
        _library.BorrowBook("ISBN-001", "LIB-1001");

        string result = _library.ViewBorrowers();

        Assert.That(result, Does.Contain("Clean Code"));
        Assert.That(result, Does.Contain("Alice Johnson"));
    }
}
