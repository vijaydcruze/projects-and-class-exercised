using NUnit.Framework;
using LibraryManagement;

namespace LibraryManagement.Tests;

/// <summary>
/// Unit tests for the <see cref="Borrower"/> class.
/// </summary>
[TestFixture]
public class BorrowerTests
{
    private Book _book1 = null!;
    private Book _book2 = null!;
    private Borrower _borrower = null!;

    [SetUp]
    public void Setup()
    {
        _book1 = new Book("Clean Code", "Robert C. Martin", "ISBN-001");
        _book2 = new Book("The Pragmatic Programmer", "Andy Hunt", "ISBN-002");
        _borrower = new Borrower("Alice Johnson", "LIB-1001");
    }

    // ─────────────────────────────────────────────
    // Constructor Tests
    // ─────────────────────────────────────────────

    [Test]
    public void Constructor_ValidParameters_CreatesBorrower()
    {
        Assert.That(_borrower.Name, Is.EqualTo("Alice Johnson"));
        Assert.That(_borrower.LibraryCardNumber, Is.EqualTo("LIB-1001"));
        Assert.That(_borrower.BorrowedBooks, Is.Empty);
    }

    [Test]
    public void Constructor_EmptyName_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => new Borrower("", "LIB-001"));
    }

    [Test]
    public void Constructor_EmptyCardNumber_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => new Borrower("Alice", ""));
    }

    // ─────────────────────────────────────────────
    // BorrowBook Tests
    // ─────────────────────────────────────────────

    [Test]
    public void BorrowBook_ValidBook_AddsToBorrowedList()
    {
        _borrower.BorrowBook(_book1);

        Assert.That(_borrower.BorrowedBooks, Contains.Item(_book1));
    }

    [Test]
    public void BorrowBook_ValidBook_MarksBookAsBorrowed()
    {
        _borrower.BorrowBook(_book1);

        Assert.That(_book1.IsBorrowed, Is.True);
    }

    [Test]
    public void BorrowBook_MultipleBooks_AllAddedToBorrowedList()
    {
        _borrower.BorrowBook(_book1);
        _borrower.BorrowBook(_book2);

        Assert.That(_borrower.BorrowedBooks.Count, Is.EqualTo(2));
        Assert.That(_borrower.BorrowedBooks, Contains.Item(_book1));
        Assert.That(_borrower.BorrowedBooks, Contains.Item(_book2));
    }

    [Test]
    public void BorrowBook_AlreadyBorrowedBySameBorrower_ThrowsInvalidOperationException()
    {
        _borrower.BorrowBook(_book1);

        Assert.Throws<InvalidOperationException>(() => _borrower.BorrowBook(_book1));
    }

    [Test]
    public void BorrowBook_NullBook_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() => _borrower.BorrowBook(null!));
    }

    // ─────────────────────────────────────────────
    // ReturnBook Tests
    // ─────────────────────────────────────────────

    [Test]
    public void ReturnBook_BorrowedBook_RemovesFromBorrowedList()
    {
        _borrower.BorrowBook(_book1);

        _borrower.ReturnBook(_book1);

        Assert.That(_borrower.BorrowedBooks, Does.Not.Contain(_book1));
    }

    [Test]
    public void ReturnBook_BorrowedBook_MarksBookAsAvailable()
    {
        _borrower.BorrowBook(_book1);

        _borrower.ReturnBook(_book1);

        Assert.That(_book1.IsBorrowed, Is.False);
    }

    [Test]
    public void ReturnBook_BookNotBorrowedByThisBorrower_ThrowsInvalidOperationException()
    {
        Assert.Throws<InvalidOperationException>(() => _borrower.ReturnBook(_book1));
    }

    [Test]
    public void ReturnBook_NullBook_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() => _borrower.ReturnBook(null!));
    }

    [Test]
    public void ReturnBook_AfterReturning_BorrowedListIsEmpty()
    {
        _borrower.BorrowBook(_book1);
        _borrower.BorrowBook(_book2);

        _borrower.ReturnBook(_book1);
        _borrower.ReturnBook(_book2);

        Assert.That(_borrower.BorrowedBooks, Is.Empty);
    }
}
