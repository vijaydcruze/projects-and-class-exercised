using NUnit.Framework;
using LibraryManagement;

namespace LibraryManagement.Tests;

/// <summary>
/// Unit tests for the <see cref="Book"/> class.
/// </summary>
[TestFixture]
public class BookTests
{
    // ─────────────────────────────────────────────
    // Constructor Tests
    // ─────────────────────────────────────────────

    [Test]
    public void Constructor_ValidParameters_CreatesBook()
    {
        var book = new Book("Clean Code", "Robert C. Martin", "978-0132350884");

        Assert.That(book.Title, Is.EqualTo("Clean Code"));
        Assert.That(book.Author, Is.EqualTo("Robert C. Martin"));
        Assert.That(book.ISBN, Is.EqualTo("978-0132350884"));
        Assert.That(book.IsBorrowed, Is.False);
    }

    [Test]
    public void Constructor_EmptyTitle_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => new Book("", "Author", "ISBN-001"));
    }

    [Test]
    public void Constructor_EmptyAuthor_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => new Book("Title", "", "ISBN-001"));
    }

    [Test]
    public void Constructor_EmptyISBN_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => new Book("Title", "Author", ""));
    }

    // ─────────────────────────────────────────────
    // Borrow Tests
    // ─────────────────────────────────────────────

    [Test]
    public void Borrow_AvailableBook_MarksBookAsBorrowed()
    {
        var book = new Book("The Pragmatic Programmer", "Andy Hunt", "978-0201616224");

        book.Borrow();

        Assert.That(book.IsBorrowed, Is.True);
    }

    [Test]
    public void Borrow_AlreadyBorrowedBook_ThrowsInvalidOperationException()
    {
        var book = new Book("The Pragmatic Programmer", "Andy Hunt", "978-0201616224");
        book.Borrow();

        Assert.Throws<InvalidOperationException>(() => book.Borrow());
    }

    // ─────────────────────────────────────────────
    // Return Tests
    // ─────────────────────────────────────────────

    [Test]
    public void Return_BorrowedBook_MarksBookAsAvailable()
    {
        var book = new Book("Design Patterns", "GoF", "978-0201633610");
        book.Borrow();

        book.Return();

        Assert.That(book.IsBorrowed, Is.False);
    }

    [Test]
    public void Return_NotBorrowedBook_ThrowsInvalidOperationException()
    {
        var book = new Book("Design Patterns", "GoF", "978-0201633610");

        Assert.Throws<InvalidOperationException>(() => book.Return());
    }

    // ─────────────────────────────────────────────
    // ToString Tests
    // ─────────────────────────────────────────────

    [Test]
    public void ToString_AvailableBook_ContainsAvailableStatus()
    {
        var book = new Book("Clean Code", "Robert C. Martin", "978-0132350884");

        string result = book.ToString();

        Assert.That(result, Does.Contain("Available"));
        Assert.That(result, Does.Contain("Clean Code"));
    }

    [Test]
    public void ToString_BorrowedBook_ContainsBorrowedStatus()
    {
        var book = new Book("Clean Code", "Robert C. Martin", "978-0132350884");
        book.Borrow();

        string result = book.ToString();

        Assert.That(result, Does.Contain("Borrowed"));
    }
}
