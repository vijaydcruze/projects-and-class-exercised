# Calculator Solution – Wipro NGA .NET Cohort

## Project Structure

```
CalculatorSolution/
├── CalculatorSolution.sln
├── CalculatorLib/
│   ├── CalculatorLib.csproj       # Class library project
│   └── Calculator.cs              # Calculator class implementation
└── CalculatorLib.Tests/
    ├── CalculatorLib.Tests.csproj # NUnit test project
    └── CalculatorTests.cs         # All unit tests
```

## Prerequisites

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)

## How to Build & Run Tests

### 1. Restore packages
```bash
dotnet restore
```

### 2. Build the solution
```bash
dotnet build
```

### 3. Run all tests
```bash
dotnet test
```

### 4. Run tests with detailed output
```bash
dotnet test --logger "console;verbosity=detailed"
```

## Calculator Class – Methods

| Method | Description |
|---|---|
| `Add(double a, double b)` | Returns the sum of a and b |
| `Subtract(double a, double b)` | Returns the difference (a - b) |
| `Multiply(double a, double b)` | Returns the product of a and b |
| `Divide(double a, double b)` | Returns the quotient; throws `DivideByZeroException` if b == 0 |

## Test Coverage

| Category | Tests |
|---|---|
| **Add** | Positive numbers, negative numbers, mixed signs, zero edge cases, decimals |
| **Subtract** | Positive numbers, negative numbers, negative result, zero, same number, decimals |
| **Multiply** | Positive, negative, zero, identity (×1), decimals |
| **Divide** | Positive, negative, zero dividend, identity (÷1), decimal result, divide-by-zero exception |

## Testing Framework

This project uses **NUnit 4** with the following packages:
- `NUnit` – Core testing framework
- `NUnit3TestAdapter` – Enables test discovery in Visual Studio and CLI
- `Microsoft.NET.Test.Sdk` – Required for `dotnet test`
