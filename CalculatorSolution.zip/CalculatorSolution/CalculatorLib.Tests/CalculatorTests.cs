using NUnit.Framework;
using CalculatorLib;

namespace CalculatorLib.Tests;

[TestFixture]
public class CalculatorTests
{
    private Calculator _calculator;

    [SetUp]
    public void Setup()
    {
        _calculator = new Calculator();
    }

    // ─────────────────────────────────────────────
    // Add Tests
    // ─────────────────────────────────────────────

    [Test]
    public void Add_TwoPositiveNumbers_ReturnsCorrectSum()
    {
        double result = _calculator.Add(5, 3);
        Assert.That(result, Is.EqualTo(8));
    }

    [Test]
    public void Add_TwoNegativeNumbers_ReturnsCorrectSum()
    {
        double result = _calculator.Add(-4, -6);
        Assert.That(result, Is.EqualTo(-10));
    }

    [Test]
    public void Add_PositiveAndNegativeNumber_ReturnsCorrectSum()
    {
        double result = _calculator.Add(10, -3);
        Assert.That(result, Is.EqualTo(7));
    }

    [Test]
    public void Add_WithZero_ReturnsSameNumber()
    {
        double result = _calculator.Add(7, 0);
        Assert.That(result, Is.EqualTo(7));
    }

    [Test]
    public void Add_BothZero_ReturnsZero()
    {
        double result = _calculator.Add(0, 0);
        Assert.That(result, Is.EqualTo(0));
    }

    [Test]
    public void Add_DecimalNumbers_ReturnsCorrectSum()
    {
        double result = _calculator.Add(1.5, 2.5);
        Assert.That(result, Is.EqualTo(4.0).Within(0.0001));
    }

    // ─────────────────────────────────────────────
    // Subtract Tests
    // ─────────────────────────────────────────────

    [Test]
    public void Subtract_TwoPositiveNumbers_ReturnsCorrectDifference()
    {
        double result = _calculator.Subtract(10, 4);
        Assert.That(result, Is.EqualTo(6));
    }

    [Test]
    public void Subtract_TwoNegativeNumbers_ReturnsCorrectDifference()
    {
        double result = _calculator.Subtract(-5, -3);
        Assert.That(result, Is.EqualTo(-2));
    }

    [Test]
    public void Subtract_ResultIsNegative_ReturnsNegativeValue()
    {
        double result = _calculator.Subtract(3, 10);
        Assert.That(result, Is.EqualTo(-7));
    }

    [Test]
    public void Subtract_Zero_ReturnsSameNumber()
    {
        double result = _calculator.Subtract(9, 0);
        Assert.That(result, Is.EqualTo(9));
    }

    [Test]
    public void Subtract_SameNumbers_ReturnsZero()
    {
        double result = _calculator.Subtract(5, 5);
        Assert.That(result, Is.EqualTo(0));
    }

    [Test]
    public void Subtract_DecimalNumbers_ReturnsCorrectDifference()
    {
        double result = _calculator.Subtract(5.5, 2.2);
        Assert.That(result, Is.EqualTo(3.3).Within(0.0001));
    }

    // ─────────────────────────────────────────────
    // Multiply Tests
    // ─────────────────────────────────────────────

    [Test]
    public void Multiply_TwoPositiveNumbers_ReturnsCorrectProduct()
    {
        double result = _calculator.Multiply(4, 5);
        Assert.That(result, Is.EqualTo(20));
    }

    [Test]
    public void Multiply_PositiveAndNegativeNumber_ReturnsNegativeProduct()
    {
        double result = _calculator.Multiply(6, -3);
        Assert.That(result, Is.EqualTo(-18));
    }

    [Test]
    public void Multiply_TwoNegativeNumbers_ReturnsPositiveProduct()
    {
        double result = _calculator.Multiply(-4, -5);
        Assert.That(result, Is.EqualTo(20));
    }

    [Test]
    public void Multiply_ByZero_ReturnsZero()
    {
        double result = _calculator.Multiply(100, 0);
        Assert.That(result, Is.EqualTo(0));
    }

    [Test]
    public void Multiply_ByOne_ReturnsSameNumber()
    {
        double result = _calculator.Multiply(7, 1);
        Assert.That(result, Is.EqualTo(7));
    }

    [Test]
    public void Multiply_DecimalNumbers_ReturnsCorrectProduct()
    {
        double result = _calculator.Multiply(2.5, 4.0);
        Assert.That(result, Is.EqualTo(10.0).Within(0.0001));
    }

    // ─────────────────────────────────────────────
    // Divide Tests
    // ─────────────────────────────────────────────

    [Test]
    public void Divide_TwoPositiveNumbers_ReturnsCorrectQuotient()
    {
        double result = _calculator.Divide(10, 2);
        Assert.That(result, Is.EqualTo(5));
    }

    [Test]
    public void Divide_PositiveByNegative_ReturnsNegativeQuotient()
    {
        double result = _calculator.Divide(9, -3);
        Assert.That(result, Is.EqualTo(-3));
    }

    [Test]
    public void Divide_NegativeByNegative_ReturnsPositiveQuotient()
    {
        double result = _calculator.Divide(-8, -4);
        Assert.That(result, Is.EqualTo(2));
    }

    [Test]
    public void Divide_ZeroByNumber_ReturnsZero()
    {
        double result = _calculator.Divide(0, 5);
        Assert.That(result, Is.EqualTo(0));
    }

    [Test]
    public void Divide_NumberByOne_ReturnsSameNumber()
    {
        double result = _calculator.Divide(15, 1);
        Assert.That(result, Is.EqualTo(15));
    }

    [Test]
    public void Divide_ResultIsDecimal_ReturnsCorrectQuotient()
    {
        double result = _calculator.Divide(7, 2);
        Assert.That(result, Is.EqualTo(3.5).Within(0.0001));
    }

    [Test]
    public void Divide_ByZero_ThrowsDivideByZeroException()
    {
        Assert.Throws<DivideByZeroException>(() => _calculator.Divide(10, 0));
    }

    [Test]
    public void Divide_ByZero_ExceptionMessageIsCorrect()
    {
        var ex = Assert.Throws<DivideByZeroException>(() => _calculator.Divide(5, 0));
        Assert.That(ex!.Message, Is.EqualTo("Cannot divide by zero."));
    }

    [Test]
    public void Divide_NegativeByZero_ThrowsDivideByZeroException()
    {
        Assert.Throws<DivideByZeroException>(() => _calculator.Divide(-10, 0));
    }
}
