/**
 * site.js – Client-side JavaScript for Assignment 1 Middleware Demo
 * Demonstrates that JS static files are served correctly from wwwroot/js/.
 */

(function () {
    'use strict';

    // ── Log page load to console ──────────────────────────────────────────
    console.info('[site.js] Static JavaScript file loaded successfully from wwwroot/js/site.js');
    console.info('[site.js] Page loaded at:', new Date().toISOString());

    // ── Show a subtle status banner when the page loads ───────────────────
    document.addEventListener('DOMContentLoaded', function () {
        const banner = document.createElement('div');
        banner.style.cssText = [
            'position:fixed', 'bottom:1rem', 'right:1rem',
            'background:#38a169', 'color:white',
            'padding:0.5rem 1rem', 'border-radius:6px',
            'font-size:0.85rem', 'font-family:Segoe UI,sans-serif',
            'box-shadow:0 2px 8px rgba(0,0,0,0.2)',
            'opacity:1', 'transition:opacity 1s ease'
        ].join(';');
        banner.textContent = '✅ Static JS loaded from /js/site.js';
        document.body.appendChild(banner);

        // Fade the banner out after 3 seconds
        setTimeout(function () {
            banner.style.opacity = '0';
            setTimeout(function () { banner.remove(); }, 1000);
        }, 3000);
    });

})();
