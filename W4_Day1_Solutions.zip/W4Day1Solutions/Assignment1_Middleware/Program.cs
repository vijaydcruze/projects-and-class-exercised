using Assignment1_Middleware.Middleware;

var builder = WebApplication.CreateBuilder(args);

// ── Service Registration ───────────────────────────────────────────────────
// Add logging (configured via appsettings.json)
builder.Services.AddLogging();

var app = builder.Build();

// ══════════════════════════════════════════════════════════════════════════════
// MIDDLEWARE PIPELINE
// Order matters: each middleware wraps all subsequent ones.
// ══════════════════════════════════════════════════════════════════════════════

// 1. Global Exception Handler — must be first so it catches errors from any
//    middleware below it. Returns a friendly HTML error page. (User Story 2)
app.UseGlobalExceptionHandler();

// 2. Request Logging — logs every request and its response status code.
//    Runs before static files so even static file requests are logged. (User Story 1 & 2)
app.UseRequestLogging();

// 3. HTTPS Redirection — redirects HTTP → HTTPS. (User Story 4)
app.UseHttpsRedirection();

// 4. Security Headers — adds CSP, HSTS, X-Frame-Options, etc. (User Story 4)
app.UseSecurityHeaders();

// 5. Static Files — serves files from wwwroot/ (HTML, CSS, JS). (User Story 3)
//    DefaultFilesMiddleware is NOT used here; we serve index.html explicitly.
app.UseStaticFiles();

// ── Demo Routes ───────────────────────────────────────────────────────────────

// Root route — redirect to the static index.html
app.MapGet("/", () => Results.Redirect("/index.html"));

// Demo route: trigger an unhandled exception to test error middleware
app.MapGet("/error-test", () =>
{
    throw new InvalidOperationException("This is a test exception to demonstrate the error middleware.");
});

// Health check endpoint
app.MapGet("/health", () => Results.Ok(new { status = "Healthy", timestamp = DateTime.UtcNow }));

app.Run();
