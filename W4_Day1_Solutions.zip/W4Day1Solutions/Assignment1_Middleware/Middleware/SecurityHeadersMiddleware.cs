namespace Assignment1_Middleware.Middleware;

/// <summary>
/// Middleware that adds security HTTP response headers to every response.
/// Fulfils User Story 4: HTTPS enforcement and XSS/CSP protection.
/// </summary>
public class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;

    public SecurityHeadersMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // ── Content-Security-Policy (XSS mitigation) ──────────────────────
        // Restricts sources for scripts, styles, and other resources.
        context.Response.Headers.Append(
            "Content-Security-Policy",
            "default-src 'self'; " +
            "script-src 'self'; " +
            "style-src 'self'; " +
            "img-src 'self' data:; " +
            "font-src 'self'; " +
            "frame-ancestors 'none';");

        // ── HTTP Strict Transport Security (force HTTPS) ───────────────────
        // Tells browsers to only use HTTPS for the next year.
        context.Response.Headers.Append(
            "Strict-Transport-Security",
            "max-age=31536000; includeSubDomains");

        // ── Prevent MIME-type sniffing ─────────────────────────────────────
        context.Response.Headers.Append("X-Content-Type-Options", "nosniff");

        // ── Prevent clickjacking ───────────────────────────────────────────
        context.Response.Headers.Append("X-Frame-Options", "DENY");

        // ── Referrer policy ───────────────────────────────────────────────
        context.Response.Headers.Append("Referrer-Policy", "no-referrer");

        await _next(context);
    }
}

/// <summary>Extension method for clean registration in Program.cs.</summary>
public static class SecurityHeadersMiddlewareExtensions
{
    public static IApplicationBuilder UseSecurityHeaders(this IApplicationBuilder builder)
        => builder.UseMiddleware<SecurityHeadersMiddleware>();
}
