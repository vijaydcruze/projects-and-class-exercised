using System.Net;

namespace Assignment1_Middleware.Middleware;

/// <summary>
/// Middleware that catches any unhandled exceptions and returns a friendly
/// error response. Fulfils User Story 2: custom error handling.
/// </summary>
public class GlobalExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<GlobalExceptionMiddleware> _logger;
    private readonly IWebHostEnvironment _env;

    public GlobalExceptionMiddleware(
        RequestDelegate next,
        ILogger<GlobalExceptionMiddleware> logger,
        IWebHostEnvironment env)
    {
        _next = next;
        _logger = logger;
        _env = env;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            // Log the full exception details on the server side
            _logger.LogError(ex,
                "Unhandled exception for {Method} {Path}",
                context.Request.Method,
                context.Request.Path);

            await HandleExceptionAsync(context, ex);
        }
    }

    private async Task HandleExceptionAsync(HttpContext context, Exception ex)
    {
        context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
        context.Response.ContentType = "text/html; charset=utf-8";

        // In development, expose exception details; in production, show generic message.
        string details = _env.IsDevelopment()
            ? $"<pre>{ex}</pre>"
            : "<p>An unexpected error occurred. Please try again later.</p>";

        string html = $"""
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8" />
                <title>500 – Server Error</title>
                <link rel="stylesheet" href="/css/site.css" />
            </head>
            <body>
                <div class="container error-page">
                    <h1>⚠️ 500 – Internal Server Error</h1>
                    <p>Something went wrong on our end.</p>
                    {details}
                    <a href="/" class="btn">← Back to Home</a>
                </div>
            </body>
            </html>
            """;

        await context.Response.WriteAsync(html);
    }
}

/// <summary>Extension method for clean registration in Program.cs.</summary>
public static class GlobalExceptionMiddlewareExtensions
{
    public static IApplicationBuilder UseGlobalExceptionHandler(this IApplicationBuilder builder)
        => builder.UseMiddleware<GlobalExceptionMiddleware>();
}
