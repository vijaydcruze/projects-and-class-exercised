namespace Assignment1_Middleware.Middleware;

/// <summary>
/// Custom middleware that logs every incoming HTTP request and the resulting
/// response status code. Fulfils User Story 1 & 2 (request/response logging).
/// </summary>
public class RequestLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<RequestLoggingMiddleware> _logger;

    public RequestLoggingMiddleware(RequestDelegate next, ILogger<RequestLoggingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // ── Log the incoming request ──────────────────────────────────────
        _logger.LogInformation(
            "[REQUEST]  {Method} {Path}{QueryString} | Host: {Host} | IP: {IP}",
            context.Request.Method,
            context.Request.Path,
            context.Request.QueryString,
            context.Request.Host,
            context.Connection.RemoteIpAddress);

        // ── Pass to next middleware and capture the response status ───────
        await _next(context);

        _logger.LogInformation(
            "[RESPONSE] {Method} {Path} → HTTP {StatusCode}",
            context.Request.Method,
            context.Request.Path,
            context.Response.StatusCode);
    }
}

/// <summary>Extension method for clean registration in Program.cs.</summary>
public static class RequestLoggingMiddlewareExtensions
{
    public static IApplicationBuilder UseRequestLogging(this IApplicationBuilder builder)
        => builder.UseMiddleware<RequestLoggingMiddleware>();
}
