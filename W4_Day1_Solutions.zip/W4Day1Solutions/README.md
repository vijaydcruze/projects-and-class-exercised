# W4 Day 1 – .NET Core Assignments
**Wipro NGA .NET Cohort**

This zip contains two independent .NET 8 projects:

---

## Assignment 1 – .NET Core Application with Middleware

**Location:** `Assignment1_Middleware/`

### Project Structure
```
Assignment1_Middleware/
├── Program.cs                            # Middleware pipeline configuration
├── Middleware/
│   ├── RequestLoggingMiddleware.cs       # Logs every request + response (US1 & US2)
│   ├── GlobalExceptionMiddleware.cs      # Custom error HTML page (US2)
│   └── SecurityHeadersMiddleware.cs      # CSP, HSTS, X-Frame-Options (US4)
└── wwwroot/
    ├── index.html                        # Static HTML page (US3)
    ├── css/site.css                      # Static CSS file (US3)
    └── js/site.js                        # Static JavaScript file (US3)
```

### Middleware Pipeline (in order)
| # | Middleware | User Story |
|---|---|---|
| 1 | `GlobalExceptionMiddleware` | US2 – custom error page |
| 2 | `RequestLoggingMiddleware` | US1 & US2 – request/response logging |
| 3 | `UseHttpsRedirection` | US4 – enforce HTTPS |
| 4 | `SecurityHeadersMiddleware` | US4 – CSP, HSTS, X-Frame-Options |
| 5 | `UseStaticFiles` | US3 – serve wwwroot/ files |

### Security Headers Added
- `Content-Security-Policy` — prevents XSS
- `Strict-Transport-Security` — forces HTTPS for 1 year
- `X-Frame-Options: DENY` — prevents clickjacking
- `X-Content-Type-Options: nosniff` — prevents MIME sniffing
- `Referrer-Policy: no-referrer`

### Run
```bash
cd Assignment1_Middleware
dotnet run
# Open https://localhost:5001
# Try https://localhost:5001/error-test to see the error page
# Try https://localhost:5001/health for health check JSON
```

---

## Assignment 2 – Razor Pages with Page Models

**Location:** `Assignment2_RazorPages/`

### Project Structure
```
Assignment2_RazorPages/
├── Program.cs
├── Models/
│   └── Item.cs                          # Domain model
├── Services/
│   └── ItemService.cs                   # In-memory data store (singleton)
└── Pages/
    ├── _ViewImports.cshtml
    ├── _ViewStart.cshtml
    ├── Shared/
    │   └── _Layout.cshtml               # Shared layout with nav bar
    ├── Index.cshtml / .cs               # Root redirect
    ├── Error.cshtml / .cs               # Error page
    └── Items/
        ├── Index.cshtml / .cs           # List page (US1, US2, US4)
        └── Add.cshtml / .cs             # Add item form (US1, US3, US4)
```

### Features Demonstrated
| Feature | Where |
|---|---|
| Razor `@foreach` loop | `Items/Index.cshtml` – renders item table |
| `@if` / `@switch` expressions | `Items/Index.cshtml` – badge colours, empty state |
| `[BindProperty]` two-way binding | `Items/Add.cshtml.cs` |
| `[BindProperty(SupportsGet=true)]` | `Items/Index.cshtml.cs` – category filter |
| DataAnnotations validation | `NewItemInput` in `Add.cshtml.cs` |
| `asp-for` / `asp-validation-for` Tag Helpers | `Items/Add.cshtml` |
| Named handler methods (`OnPostDelete`) | `Items/Index.cshtml.cs` |
| `TempData` (Post-Redirect-Get pattern) | Both PageModels |
| Anti-forgery tokens | All POST forms |
| Dependency injection via constructor | Both PageModels |

### Run
```bash
cd Assignment2_RazorPages
dotnet run
# Open https://localhost:5001
# Redirects to /Items — the item list page
# Click "Add New Item" to test form submission and validation
```
