using Assignment2_RazorPages.Services;

var builder = WebApplication.CreateBuilder(args);

// ── Service Registration ───────────────────────────────────────────────────

// Register Razor Pages support
builder.Services.AddRazorPages();

// Register ItemService as a singleton so data persists across requests
builder.Services.AddSingleton<ItemService>();

var app = builder.Build();

// ── Middleware Pipeline ────────────────────────────────────────────────────

if (!app.Environment.IsDevelopment())
{
    // Use the built-in exception handler page in production
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}
else
{
    app.UseDeveloperExceptionPage();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// Map Razor Pages — routes are derived from the Pages/ folder structure
app.MapRazorPages();

app.Run();
