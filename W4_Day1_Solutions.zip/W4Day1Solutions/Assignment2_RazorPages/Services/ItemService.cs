using Assignment2_RazorPages.Models;

namespace Assignment2_RazorPages.Services;

/// <summary>
/// A simple in-memory store for <see cref="Item"/> objects.
/// Registered as a singleton so data persists for the lifetime of the app.
/// In a real application this would be backed by a database.
/// </summary>
public class ItemService
{
    private readonly List<Item> _items = new();
    private int _nextId = 1;

    public ItemService()
    {
        // Seed with some sample data so the list page is not empty on first run
        Add(new Item { Name = "Clean Code",             Category = "Books",       Description = "Robert C. Martin's guide to writing readable code." });
        Add(new Item { Name = "Laptop Stand",           Category = "Equipment",   Description = "Ergonomic aluminium stand for 13–17\" laptops." });
        Add(new Item { Name = "Unit Testing Handbook",  Category = "Books",       Description = "Comprehensive guide to writing reliable unit tests." });
        Add(new Item { Name = "Mechanical Keyboard",    Category = "Equipment",   Description = "Tactile Cherry MX Blue switches." });
    }

    /// <summary>Returns all items, newest first.</summary>
    public IReadOnlyList<Item> GetAll() =>
        _items.OrderByDescending(i => i.AddedOn).ToList().AsReadOnly();

    /// <summary>Returns items filtered by category (case-insensitive). Null/empty returns all.</summary>
    public IReadOnlyList<Item> GetByCategory(string? category) =>
        string.IsNullOrWhiteSpace(category)
            ? GetAll()
            : _items.Where(i => i.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(i => i.AddedOn)
                    .ToList().AsReadOnly();

    /// <summary>Returns all distinct category names.</summary>
    public IReadOnlyList<string> GetCategories() =>
        _items.Select(i => i.Category).Distinct().OrderBy(c => c).ToList().AsReadOnly();

    /// <summary>Finds an item by its ID, or returns null if not found.</summary>
    public Item? GetById(int id) => _items.FirstOrDefault(i => i.Id == id);

    /// <summary>Adds a new item and assigns it the next ID.</summary>
    public void Add(Item item)
    {
        item.Id     = _nextId++;
        item.AddedOn = DateTime.Now;
        _items.Add(item);
    }

    /// <summary>Removes an item by ID. Returns true if removed, false if not found.</summary>
    public bool Remove(int id)
    {
        var item = GetById(id);
        if (item == null) return false;
        _items.Remove(item);
        return true;
    }
}
