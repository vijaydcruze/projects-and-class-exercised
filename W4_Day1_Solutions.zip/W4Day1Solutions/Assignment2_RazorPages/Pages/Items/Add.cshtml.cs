using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Assignment2_RazorPages.Models;
using Assignment2_RazorPages.Services;

namespace Assignment2_RazorPages.Pages.Items;

/// <summary>
/// PageModel for the Add Item page.
/// Demonstrates: [BindProperty], DataAnnotations validation,
/// OnGet / OnPost handler methods, and TempData for post-redirect-get pattern.
/// </summary>
public class AddModel : PageModel
{
    private readonly ItemService _itemService;

    // ── Bound Property (two-way data binding) ────────────────────────────

    /// <summary>
    /// The new item being created.
    /// [BindProperty] means ASP.NET Core will map POST form fields to this object.
    /// </summary>
    [BindProperty]
    public NewItemInput NewItem { get; set; } = new();

    /// <summary>Existing category names, used to power the datalist autocomplete.</summary>
    public IReadOnlyList<string> ExistingCategories { get; private set; } = Array.Empty<string>();

    public AddModel(ItemService itemService)
    {
        _itemService = itemService;
    }

    /// <summary>GET handler — display the blank form.</summary>
    public void OnGet()
    {
        ExistingCategories = _itemService.GetCategories();
    }

    /// <summary>
    /// POST handler — validate the form and, if valid, add the item.
    /// Uses the Post-Redirect-Get pattern to avoid duplicate submissions on refresh.
    /// </summary>
    public IActionResult OnPost()
    {
        // Repopulate categories in case we need to re-render the form
        ExistingCategories = _itemService.GetCategories();

        // If model validation fails, redisplay the form with error messages
        if (!ModelState.IsValid)
            return Page();

        // Map the validated input to the domain model
        var item = new Item
        {
            Name        = NewItem.Name.Trim(),
            Category    = NewItem.Category.Trim(),
            Description = NewItem.Description?.Trim() ?? string.Empty
        };

        _itemService.Add(item);

        // Store a success message in TempData (survives the redirect)
        TempData["SuccessMessage"] = $"'{item.Name}' was added successfully!";

        // Redirect to the list page (Post-Redirect-Get pattern)
        return RedirectToPage("/Items/Index");
    }
}

/// <summary>
/// Input model with DataAnnotations validation rules.
/// Kept separate from the domain <see cref="Item"/> to avoid over-posting.
/// </summary>
public class NewItemInput
{
    [Required(ErrorMessage = "Item name is required.")]
    [StringLength(100, MinimumLength = 2, ErrorMessage = "Name must be between 2 and 100 characters.")]
    public string Name { get; set; } = string.Empty;

    [Required(ErrorMessage = "Category is required.")]
    [StringLength(50, ErrorMessage = "Category must not exceed 50 characters.")]
    public string Category { get; set; } = string.Empty;

    [StringLength(500, ErrorMessage = "Description must not exceed 500 characters.")]
    public string? Description { get; set; }
}
