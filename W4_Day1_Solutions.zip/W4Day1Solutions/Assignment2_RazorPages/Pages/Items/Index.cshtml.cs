using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Assignment2_RazorPages.Models;
using Assignment2_RazorPages.Services;

namespace Assignment2_RazorPages.Pages.Items;

/// <summary>
/// PageModel for the Item list page.
/// Handles: GET (load/filter items) and POST Delete handler.
/// Demonstrates: property binding, TempData, handler methods.
/// </summary>
public class IndexModel : PageModel
{
    private readonly ItemService _itemService;

    // ── Bound Properties ──────────────────────────────────────────────────

    /// <summary>The items to display, filtered by SelectedCategory.</summary>
    public IReadOnlyList<Item> Items { get; private set; } = Array.Empty<Item>();

    /// <summary>All distinct category names for the filter dropdown.</summary>
    public IReadOnlyList<string> Categories { get; private set; } = Array.Empty<string>();

    /// <summary>
    /// The currently selected category filter.
    /// Bound from the query string: /Items?category=Books
    /// </summary>
    [BindProperty(SupportsGet = true)]
    public string? SelectedCategory { get; set; }

    public IndexModel(ItemService itemService)
    {
        _itemService = itemService;
    }

    /// <summary>
    /// GET handler — loads and (optionally) filters the item list.
    /// </summary>
    public void OnGet()
    {
        Categories = _itemService.GetCategories();
        Items      = _itemService.GetByCategory(SelectedCategory);
    }

    /// <summary>
    /// POST handler for deleting an item by ID.
    /// Named handler "Delete" maps to asp-page-handler="Delete".
    /// </summary>
    public IActionResult OnPostDelete(int id)
    {
        bool removed = _itemService.Remove(id);

        TempData["SuccessMessage"] = removed
            ? $"Item #{id} has been deleted."
            : $"Item #{id} was not found.";

        return RedirectToPage();
    }

    /// <summary>Returns a CSS badge class name based on the category string.</summary>
    public string GetBadgeClass(string category) => category switch
    {
        "Books"     => "badge-blue",
        "Equipment" => "badge-green",
        _           => "badge-purple"
    };
}
