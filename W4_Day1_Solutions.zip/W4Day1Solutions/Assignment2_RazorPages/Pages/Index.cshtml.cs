using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Assignment2_RazorPages.Pages;

/// <summary>Root page — immediately redirects to the Items list.</summary>
public class IndexModel : PageModel
{
    public IActionResult OnGet() => RedirectToPage("/Items/Index");
}
