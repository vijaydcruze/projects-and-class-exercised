namespace Assignment2_RazorPages.Models;

/// <summary>
/// Represents a single item in the library/inventory list.
/// Used across both the Index (list) and AddItem pages.
/// </summary>
public class Item
{
    /// <summary>Auto-incremented unique identifier.</summary>
    public int Id { get; set; }

    /// <summary>Name/title of the item.</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>Optional category for grouping items.</summary>
    public string Category { get; set; } = string.Empty;

    /// <summary>Longer description of the item.</summary>
    public string Description { get; set; } = string.Empty;

    /// <summary>Date and time the item was added.</summary>
    public DateTime AddedOn { get; set; } = DateTime.Now;
}
