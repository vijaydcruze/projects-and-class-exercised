
using System;
using SecureUserManagement.Services;

namespace SecureUserManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            var authService = new AuthService();
            authService.Register("admin", "password123");
            bool success = authService.Login("admin", "password123");
            Console.WriteLine("Login Success: " + success);
        }
    }
}
