
namespace SecureUserManagement
{
    public class User
    {
        public string Username { get; set; }
        public string HashedPassword { get; set; }
        public string EncryptedData { get; set; }
    }
}
