
using System;
using System.Collections.Generic;
using SecureUserManagement.Utils;

namespace SecureUserManagement.Services
{
    public class AuthService
    {
        private static readonly Dictionary<string, User> _users = new();

        public void Register(string username, string password)
        {
            try
            {
                string hashed = HashHelper.ComputeSha256Hash(password);
                string encryptedData = EncryptionHelper.Encrypt("Sensitive Info");

                _users[username] = new User
                {
                    Username = username,
                    HashedPassword = hashed,
                    EncryptedData = encryptedData
                };

                Logger.Log("User registered: " + username);
            }
            catch (Exception ex)
            {
                Logger.LogError("Registration failed", ex);
                throw;
            }
        }

        public bool Login(string username, string password)
        {
            try
            {
                if (!_users.ContainsKey(username)) return false;

                string hashed = HashHelper.ComputeSha256Hash(password);
                bool success = _users[username].HashedPassword == hashed;

                Logger.Log("Login attempt: " + username);
                return success;
            }
            catch (Exception ex)
            {
                Logger.LogError("Login failed", ex);
                return false;
            }
        }
    }
}
