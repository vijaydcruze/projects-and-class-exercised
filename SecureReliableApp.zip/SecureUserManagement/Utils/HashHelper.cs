
using System.Security.Cryptography;
using System.Text;

namespace SecureUserManagement.Utils
{
    public static class HashHelper
    {
        public static string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder = new();
                foreach (byte t in bytes)
                    builder.Append(t.ToString("x2"));
                return builder.ToString();
            }
        }
    }
}
