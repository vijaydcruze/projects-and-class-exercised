
using System;
using System.IO;

namespace SecureUserManagement.Utils
{
    public static class Logger
    {
        private static readonly string logFile = "app.log";

        public static void Log(string message)
        {
            File.AppendAllText(logFile,
                $"{DateTime.Now} INFO: {message}{Environment.NewLine}");
        }

        public static void LogError(string message, Exception ex)
        {
            File.AppendAllText(logFile,
                $"{DateTime.Now} ERROR: {message} - {ex.Message}{Environment.NewLine}");
        }
    }
}
