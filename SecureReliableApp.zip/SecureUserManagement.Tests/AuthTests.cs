
using Xunit;
using SecureUserManagement.Services;
using SecureUserManagement.Utils;

namespace SecureUserManagement.Tests
{
    public class AuthTests
    {
        [Fact]
        public void Register_And_Login_Should_Work()
        {
            var auth = new AuthService();
            auth.Register("test", "1234");
            Assert.True(auth.Login("test", "1234"));
        }

        [Fact]
        public void Hash_Should_Be_Consistent()
        {
            var hash1 = HashHelper.ComputeSha256Hash("abc");
            var hash2 = HashHelper.ComputeSha256Hash("abc");
            Assert.Equal(hash1, hash2);
        }

        [Fact]
        public void Encryption_Should_Encrypt_And_Decrypt()
        {
            string text = "hello";
            var encrypted = EncryptionHelper.Encrypt(text);
            var decrypted = EncryptionHelper.Decrypt(encrypted);
            Assert.Equal(text, decrypted);
        }
    }
}
